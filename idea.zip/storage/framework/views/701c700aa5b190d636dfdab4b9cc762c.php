<?php if(session('success')): ?>
    <script>
        Swal.fire({
            title: 'Success!',
            text: "<?php echo e(session('success')); ?>",
            icon: 'success',
            confirmButtonText: 'Okay'
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        Swal.fire({
            title: 'Oops...',
            text: "<?php echo e(session('error')); ?>",
            icon: 'error',

        });
    </script>
<?php endif; ?>
<?php /**PATH P:\OFFICE\bangla-call\resources\views/alert.blade.php ENDPATH**/ ?>